#pragma once
#include "stdafx.h"

namespace auth {
	bool run();
	bool run_heartbeat();
}